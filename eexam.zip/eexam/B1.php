<?php
include 'Template_Header.html';
?>
<html>
<head> 
<title>
Company
</title>
</head>
<body align=left>
<hr>
<form action="B2.php" method="POST">
<h2> Registration Page </h2>
Seller Name <input type="text" name="sellername"> <br>
Company Name <input type="text" name="companyname"> <br>
Product Name <input type="text" name="productname"> <br>
Product Description <input type="text" name="description"> <br>
Address<input type="text" name="address"> <br>
State<input type="text" name="state"> <br>
City<input type="text" name="city"> <br>
Pin Code<input type="number" name="pincode"> <br>
Submit <input type="Submit" name="Submit">
</form>
</body>
</html>
<?php
include 'Template_Footer.html';
?>

