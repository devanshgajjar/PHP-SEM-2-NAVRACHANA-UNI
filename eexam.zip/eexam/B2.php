<?php
if($_SERVER['REQUEST_METHOD']=="POST")
{
	$servername=$_POST['servername'];
	$companyname=$_POST['companyname'];
	$servername=$_POST['servername'];
	$age=$_GET['Years'];
	$age2=2018-$age;
?>
	
}
function greeting($x)
	{
		global $uname;
		echo"Greetings $uname";
		
	}
f
?>
	
	
	

